# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.10.1'
__hash__ = 'Unknown'
__date__ = '20180726'
